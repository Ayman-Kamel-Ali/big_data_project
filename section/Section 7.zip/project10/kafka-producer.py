from kafka import KafkaProducer
import json

# Create a Kafka producer instance
producer = KafkaProducer(bootstrap_servers='localhost:9092')

# Define the topic to which you want to produce data
topic = 'test'

# Create a dictionary representing your JSON data
data = {
    'id': 1,
    'name': 'ali',
    'age': 20
}

# Convert the dictionary to JSON string
json_data = json.dumps(data)

# Produce the JSON data to Kafka topic
producer.send(topic, value=json_data.encode('utf-8'))

# Flush and close the producer connection
producer.flush()
producer.close()
